
export const MISSION = {
  title: "Standing with Humanity on the Frontlines",
  intro: "Frontlines raises funds to assist communities devastated by the Gaza-Israel and Ukraine-Russia conflicts. We focus on immediate relief, rebuilding, and restoring dignity to families who have lost homes and livelihoods."
};

export const TEAM = [
  { name: "Priya Maydipalle", role: "President & Founder" },
  { name: "Hasini Garrepalli", role: "President & Treasurer" },
  { name: "Yashu Kukula", role: "Secretary" }
];
