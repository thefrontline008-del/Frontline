
export const CONFIG = {
  GOFUNDME_URL: "https://www.gofundme.com/f/your-campaign-slug",
  CONTACT_EMAIL: "contact@frontlines.org",
  GOAL_AMOUNT: 20000,
  INITIAL_RAISED: 7250
};
