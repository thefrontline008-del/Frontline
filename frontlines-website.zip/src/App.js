
import React, { useEffect, useState } from 'react';
import { CONFIG } from './config';
import { MISSION, TEAM } from './data';

function Header() {
  return (
    <header className="container header">
      <div className="logo">Frontlines</div>
      <nav className="nav small">
        <a href="#mission">Mission</a>
        <a href="#team">Team</a>
        <a href="#donate">Donate</a>
        <a href="#contact">Contact</a>
      </nav>
    </header>
  );
}

function Hero() {
  return (
    <section className="container hero">
      <h1>{MISSION.title}</h1>
      <p className="small" style={{marginTop:12}}>{MISSION.intro}</p>
      <div style={{marginTop:18}}>
        <a href={CONFIG.GOFUNDME_URL} target="_blank" rel="noopener noreferrer">
          <button className="button">💚 Donate Now</button>
        </a>
      </div>
    </section>
  );
}

function Team() {
  return (
    <section id="team" className="container section">
      <h2>Meet Our Team</h2>
      <div className="grid grid-3" style={{marginTop:16}}>
        {TEAM.map(member => (
          <div key={member.name} className="card">
            <h3 style={{margin:0}}>{member.name}</h3>
            <p className="small" style={{marginTop:8}}>{member.role}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function Donate() {
  const [raised, setRaised] = useState(CONFIG.INITIAL_RAISED);
  const goal = CONFIG.GOAL_AMOUNT;
  const pct = Math.min((raised/goal)*100, 100);

  // Placeholder: auto-update simulation
  useEffect(()=> {
    const t = setTimeout(()=> {
      // no-op for now; integrate with GoFundMe API or manual update later
    }, 500);
    return ()=> clearTimeout(t);
  },[]);

  return (
    <section id="donate" className="container section">
      <h2>Support Our Work</h2>
      <p className="small">Every donation brings us closer to rebuilding lives.</p>

      <div style={{marginTop:14, marginBottom:8}}>
        <div className="progress-outer">
          <div className="progress-inner" style={{width: `${pct}%`}} />
        </div>
        <div style={{display:'flex', justifyContent:'space-between', marginTop:8}}>
          <div className="small"><strong>${raised.toLocaleString()}</strong> raised</div>
          <div className="small">Goal: ${goal.toLocaleString()}</div>
        </div>
      </div>

      <div style={{marginTop:18}}>
        <a href={CONFIG.GOFUNDME_URL} target="_blank" rel="noopener noreferrer">
          <button className="button">Donate via GoFundMe</button>
        </a>
      </div>
      <p className="small" style={{marginTop:10}}>Tip: ask donors to enable employer matching to double their impact.</p>
    </section>
  );
}

function Impact() {
  return (
    <section className="container section" id="impact">
      <h2>Impact</h2>
      <p className="small">We focus on immediate relief, emergency supplies, shelter repair, and partner coordination on the ground. Funds are distributed to vetted local partners and humanitarian organizations working in affected regions.</p>
    </section>
  );
}

function Contact() {
  return (
    <section className="container section" id="contact">
      <h2>Contact</h2>
      <p className="small">Email: {CONFIG.CONTACT_EMAIL}</p>
      <form onSubmit={(e)=>{ e.preventDefault(); alert('This contact form is a demo. Configure an email service to receive messages.'); }}>
        <div style={{display:'grid', gap:10, maxWidth:500}}>
          <input name="name" placeholder="Your name" />
          <input name="email" placeholder="Your email" />
          <textarea name="msg" placeholder="Message" rows={4} />
          <button className="button" type="submit">Send Message</button>
        </div>
      </form>
    </section>
  );
}

function Footer() {
  return (
    <footer className="container footer">
      <div className="small">© {new Date().getFullYear()} Frontlines</div>
      <div className="small">
        <a href="#" style={{marginRight:12}}>Instagram</a>
        <a href="#" style={{marginRight:12}}>X</a>
        <a href="#" style={{marginRight:12}}>LinkedIn</a>
        <a href="#">Facebook</a>
      </div>
    </footer>
  );
}

export default function App(){
  return (
    <div>
      <Header />
      <main>
        <Hero />
        <section id="mission" className="container section">
          <h2>Our Mission</h2>
          <p className="small">{MISSION.intro}</p>
        </section>
        <Team />
        <Impact />
        <Donate />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
