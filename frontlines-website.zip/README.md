
# Frontlines — Nonprofit Website (React Starter)

This is a ready-to-run React starter project for **Frontlines**, a nonprofit fundraising organization.
It includes pages, a Donate button linked to GoFundMe, a progress bar, contact form stub, and social links.

## Quick start (run locally)
1. Install Node.js (v16+) and npm.
2. In the project folder:
   ```bash
   npm install
   npm start
   ```
3. Open http://localhost:3000

## Replace placeholders
- Update `src/config.js` with your real GoFundMe URL and contact email.
- Replace images in `public/` or `src/assets/` with your own photos/logo.
- Edit content in `src/data.js` for mission text and team bios.

## Deploy to Netlify (recommended)
1. Create a Netlify account.
2. In Netlify dashboard, choose "Sites" → "New site from Git" (or drag & drop build folder).
3. Connect your GitHub repo or drag the `build` folder after running `npm run build`.
4. Add a custom domain in Netlify settings (e.g. `frontlines.org`).

### Point your domain to Netlify
- In your domain registrar (Namecheap / Google Domains / GoDaddy):
  - Add a CNAME record for `www` pointing to `your-site.netlify.app`.
  - Add Netlify's recommended A records for the root domain or use Netlify DNS.
- Netlify will provision HTTPS automatically.

## Deploy to Vercel
1. Create a Vercel account and "New Project" → import from Git.
2. Set the build command `npm run build` and output directory `build`.
3. Add custom domain via Vercel dashboard and follow DNS instructions.

## Notes on legitimacy & trust
- Add an "About" page with team bios, EIN (if you have one), and a transparent "Where the money goes" breakdown.
- Use a professional email (e.g. contact@frontlines.org) and add social media links.
- Consider registering as a 501(c)(3) or stating partnerships with vetted charities if you're acting as a donor conduit.

If you want, I can:
- Create a GitHub repo and push this for you (you'd need to provide access token or I can provide exact `git` commands).
- Swap to Tailwind / Tailwind + shadcn UI for a fancier design.
- Add actual GoFundMe API integration (requires campaign access).
